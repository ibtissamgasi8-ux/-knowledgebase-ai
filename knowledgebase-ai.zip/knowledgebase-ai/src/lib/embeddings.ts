import { z } from "zod";
import { EMBEDDING_DIMENSIONS, getEnv } from "./env";
import { HttpError } from "./http";

const matrixSchema = z.array(z.array(z.number()));
const vectorSchema = z.array(z.number());

const BATCH_SIZE = 16;
const CONCURRENCY = 3;
const MAX_ATTEMPTS = 4;
const REQUEST_TIMEOUT_MS = 25_000;

function endpointUrl(): string {
  const env = getEnv();
  if (env.HF_EMBEDDING_URL) return env.HF_EMBEDDING_URL;
  return `https://router.huggingface.co/hf-inference/models/${env.HF_EMBEDDING_MODEL}/pipeline/feature-extraction`;
}

const sleep = (ms: number): Promise<void> => new Promise((resolve) => setTimeout(resolve, ms));

function unavailable(detail: string): HttpError {
  return new HttpError(
    502,
    `Embedding service failed (${detail}). Check HF_API_TOKEN and HF_EMBEDDING_MODEL, and confirm the model is served by Hugging Face Inference Providers.`,
  );
}

async function requestBatch(inputs: string[]): Promise<number[][]> {
  const env = getEnv();
  let lastError = "no response";

  for (let attempt = 1; attempt <= MAX_ATTEMPTS; attempt += 1) {
    let response: Response;
    try {
      response = await fetch(endpointUrl(), {
        method: "POST",
        headers: {
          Authorization: `Bearer ${env.HF_API_TOKEN}`,
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ inputs }),
        signal: AbortSignal.timeout(REQUEST_TIMEOUT_MS),
      });
    } catch (cause) {
      lastError = cause instanceof Error ? cause.message : "network error";
      await sleep(500 * attempt);
      continue;
    }

    if (response.ok) {
      const body: unknown = await response.json();
      const matrix = matrixSchema.safeParse(body);
      if (matrix.success && matrix.data.length === inputs.length) return matrix.data;
      const single = vectorSchema.safeParse(body);
      if (single.success && inputs.length === 1) return [single.data];
      throw new HttpError(
        502,
        "Unexpected embedding response shape. The model must return one sentence-level vector per input (not token-level vectors).",
      );
    }

    const detail = (await response.text()).slice(0, 300);
    lastError = `HTTP ${response.status}: ${detail}`;
    const retryable = response.status === 429 || response.status === 503 || response.status >= 500;
    if (!retryable) break;
    await sleep(800 * attempt);
  }

  throw unavailable(lastError);
}

function normalize(vector: number[]): number[] {
  if (vector.length !== EMBEDDING_DIMENSIONS) {
    throw new HttpError(
      500,
      `The embedding model returned ${vector.length} dimensions, but the database expects ${EMBEDDING_DIMENSIONS}. Use a ${EMBEDDING_DIMENSIONS}-dimension model.`,
    );
  }
  let sumSquares = 0;
  for (const value of vector) sumSquares += value * value;
  const norm = Math.sqrt(sumSquares);
  if (!Number.isFinite(norm) || norm === 0) {
    throw new HttpError(502, "The embedding model returned an invalid (zero) vector.");
  }
  return vector.map((value) => value / norm);
}

/** Embeds texts with the configured Hugging Face model. `kind` selects the E5-style prefix. */
export async function embedTexts(texts: string[], kind: "passage" | "query"): Promise<number[][]> {
  if (texts.length === 0) return [];
  const env = getEnv();
  const prefix = kind === "query" ? env.EMBEDDING_QUERY_PREFIX : env.EMBEDDING_PASSAGE_PREFIX;
  const inputs = texts.map((text) => `${prefix}${text}`);

  const batches: string[][] = [];
  for (let start = 0; start < inputs.length; start += BATCH_SIZE) {
    batches.push(inputs.slice(start, start + BATCH_SIZE));
  }

  const results: number[][][] = [];
  let nextBatch = 0;
  const worker = async (): Promise<void> => {
    for (;;) {
      const index = nextBatch;
      nextBatch += 1;
      const batch = batches[index];
      if (!batch) return;
      results[index] = await requestBatch(batch);
    }
  };
  await Promise.all(Array.from({ length: Math.min(CONCURRENCY, batches.length) }, () => worker()));

  return results.flat().map(normalize);
}

/** Formats a vector as a pgvector/halfvec text literal, e.g. "[0.1,0.2]". */
export function toPgVector(vector: number[]): string {
  return `[${vector.map((value) => Math.round(value * 1e6) / 1e6).join(",")}]`;
}
