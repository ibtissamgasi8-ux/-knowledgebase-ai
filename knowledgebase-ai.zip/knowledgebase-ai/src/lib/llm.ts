import { z } from "zod";
import { getEnv } from "./env";
import { HttpError } from "./http";

export interface ChatMessage {
  role: "system" | "user" | "assistant";
  content: string;
}

const completionSchema = z.object({
  choices: z
    .array(z.object({ message: z.object({ content: z.string().nullable() }) }))
    .min(1),
});

const OPENROUTER_URL = "https://openrouter.ai/api/v1/chat/completions";

function describeFailure(status: number, detail: string): string {
  if (status === 401) return "OpenRouter rejected the API key (check OPENROUTER_API_KEY).";
  if (status === 402) return "OpenRouter reports insufficient credits for this model.";
  if (status === 404) return "OpenRouter could not find the model (check OPENROUTER_MODEL).";
  if (status === 429) return "OpenRouter rate limit reached. Try again in a moment.";
  return `OpenRouter request failed (HTTP ${status}): ${detail}`;
}

export async function generateAnswer(messages: ChatMessage[], maxTokens = 900): Promise<string> {
  const env = getEnv();
  const headers: Record<string, string> = {
    Authorization: `Bearer ${env.OPENROUTER_API_KEY}`,
    "Content-Type": "application/json",
    "X-Title": "KnowledgeBase AI",
  };
  if (env.OPENROUTER_SITE_URL) headers["HTTP-Referer"] = env.OPENROUTER_SITE_URL;

  let response: Response;
  try {
    response = await fetch(OPENROUTER_URL, {
      method: "POST",
      headers,
      body: JSON.stringify({
        model: env.OPENROUTER_MODEL,
        messages,
        temperature: 0.2,
        max_tokens: maxTokens,
      }),
      signal: AbortSignal.timeout(40_000),
    });
  } catch (cause) {
    const reason = cause instanceof Error ? cause.message : "network error";
    throw new HttpError(502, `Could not reach OpenRouter (${reason}).`);
  }

  if (!response.ok) {
    const detail = (await response.text()).slice(0, 300);
    throw new HttpError(502, describeFailure(response.status, detail));
  }

  const parsed = completionSchema.safeParse(await response.json());
  const content = parsed.success ? parsed.data.choices[0]?.message.content?.trim() : undefined;
  if (!content) throw new HttpError(502, "The AI model returned an empty answer. Try again or pick another model.");
  return content;
}
