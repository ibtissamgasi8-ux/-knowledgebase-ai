import { z } from "zod";

/* ---------- Database-backed entities (snake_case, as stored) ---------- */

export const documentSchema = z.object({
  id: z.string().uuid(),
  title: z.string(),
  filename: z.string(),
  file_type: z.enum(["txt", "md"]),
  size_bytes: z.number().int(),
  chunk_count: z.number().int(),
  created_at: z.string(),
});
export type DocumentRow = z.infer<typeof documentSchema>;

export const conversationSchema = z.object({
  id: z.string().uuid(),
  title: z.string(),
  created_at: z.string(),
  updated_at: z.string(),
});
export type Conversation = z.infer<typeof conversationSchema>;

export const sourceSchema = z.object({
  ref: z.number().int(),
  documentId: z.string().uuid(),
  title: z.string(),
  heading: z.string().nullable(),
  chunkIndex: z.number().int(),
  similarity: z.number(),
  excerpt: z.string(),
  cited: z.boolean(),
});
export type Source = z.infer<typeof sourceSchema>;

export const messageSchema = z.object({
  id: z.string().uuid(),
  conversation_id: z.string().uuid(),
  role: z.enum(["user", "assistant"]),
  content: z.string(),
  sources: z.array(sourceSchema),
  created_at: z.string(),
});
export type Message = z.infer<typeof messageSchema>;

/* ---------- Vector search ---------- */

export const matchRowSchema = z.object({
  id: z.string().uuid(),
  document_id: z.string().uuid(),
  document_title: z.string(),
  chunk_index: z.number().int(),
  heading: z.string().nullable(),
  content: z.string(),
  similarity: z.number(),
});
export type MatchRow = z.infer<typeof matchRowSchema>;

export const searchResultSchema = z.object({
  chunkId: z.string().uuid(),
  documentId: z.string().uuid(),
  title: z.string(),
  heading: z.string().nullable(),
  chunkIndex: z.number().int(),
  similarity: z.number(),
  content: z.string(),
});
export type SearchResult = z.infer<typeof searchResultSchema>;

/* ---------- Request bodies ---------- */

export const uuidSchema = z.string().uuid("Invalid id.");

export const chatRequestSchema = z.object({
  question: z.string().trim().min(1, "Question is empty.").max(2000, "Question is too long (max 2000 characters)."),
  conversationId: z.string().uuid().optional(),
  documentIds: z.array(z.string().uuid()).max(50).optional(),
});
export type ChatRequest = z.infer<typeof chatRequestSchema>;

export const searchRequestSchema = z.object({
  query: z.string().trim().min(1, "Query is empty.").max(500, "Query is too long (max 500 characters)."),
  limit: z.number().int().min(1).max(20).default(8),
  documentIds: z.array(z.string().uuid()).max(50).optional(),
});

/* ---------- Response bodies (validated again on the client) ---------- */

export const errorBodySchema = z.object({ error: z.string() });
export const okSchema = z.object({ ok: z.literal(true) });
export const accessStatusSchema = z.object({ required: z.boolean() });

export const documentsResponseSchema = z.object({ documents: z.array(documentSchema) });
export const documentResponseSchema = z.object({ document: documentSchema });
export const conversationsResponseSchema = z.object({ conversations: z.array(conversationSchema) });
export const conversationDetailSchema = z.object({
  conversation: conversationSchema,
  messages: z.array(messageSchema),
});
export const chatResponseSchema = z.object({
  conversation: conversationSchema,
  userMessage: messageSchema,
  assistantMessage: messageSchema,
});
export const searchResponseSchema = z.object({ results: z.array(searchResultSchema) });

export const healthCheckSchema = z.object({
  name: z.string(),
  ok: z.boolean(),
  detail: z.string(),
});
export const healthResponseSchema = z.object({ checks: z.array(healthCheckSchema) });
export type HealthCheck = z.infer<typeof healthCheckSchema>;
