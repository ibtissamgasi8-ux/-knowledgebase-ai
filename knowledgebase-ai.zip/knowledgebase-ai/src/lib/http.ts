import { NextResponse } from "next/server";
import { ZodError } from "zod";
import { isAuthorized } from "./auth";
import { EnvError } from "./env";

export class HttpError extends Error {
  readonly status: number;
  constructor(status: number, message: string) {
    super(message);
    this.name = "HttpError";
    this.status = status;
  }
}

export function jsonResponse<T>(data: T, status = 200): NextResponse {
  return NextResponse.json(data, { status, headers: { "Cache-Control": "no-store" } });
}

export function errorResponse(error: unknown): NextResponse {
  if (error instanceof HttpError) return jsonResponse({ error: error.message }, error.status);
  if (error instanceof EnvError) return jsonResponse({ error: error.message }, 500);
  if (error instanceof ZodError) {
    const first = error.issues[0];
    const where = first && first.path.length > 0 ? `${first.path.join(".")}: ` : "";
    return jsonResponse({ error: `Invalid request. ${where}${first?.message ?? "Validation failed."}` }, 400);
  }
  console.error("Unhandled API error", error);
  return jsonResponse({ error: "Unexpected server error." }, 500);
}

export async function readJson(req: Request): Promise<unknown> {
  try {
    return await req.json();
  } catch {
    throw new HttpError(400, "Request body must be valid JSON.");
  }
}

interface RouteOptions {
  /** Skip the access-code check (only for the /api/access endpoint). */
  public?: boolean;
}

/** Wraps a route handler with access-code checking and uniform error responses. */
export function route<C = unknown>(
  handler: (req: Request, ctx: C) => Promise<Response>,
  options: RouteOptions = {},
) {
  return async (req: Request, ctx: C): Promise<Response> => {
    try {
      if (!options.public && !isAuthorized(req)) {
        return jsonResponse({ error: "Access code required." }, 401);
      }
      return await handler(req, ctx);
    } catch (error) {
      return errorResponse(error);
    }
  };
}
