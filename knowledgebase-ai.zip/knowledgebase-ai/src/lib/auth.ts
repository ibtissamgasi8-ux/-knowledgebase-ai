import { createHash, timingSafeEqual } from "node:crypto";

function configuredCode(): string | null {
  const value = process.env.APP_ACCESS_CODE?.trim();
  return value ? value : null;
}

const digest = (value: string): Buffer => createHash("sha256").update(value).digest();

export function accessRequired(): boolean {
  return configuredCode() !== null;
}

export function isCodeValid(provided: string): boolean {
  const code = configuredCode();
  if (!code) return true;
  return timingSafeEqual(digest(code), digest(provided));
}

export function isAuthorized(req: Request): boolean {
  return isCodeValid(req.headers.get("x-access-code") ?? "");
}
