import { z } from "zod";
import {
  accessStatusSchema,
  chatResponseSchema,
  conversationDetailSchema,
  conversationsResponseSchema,
  documentResponseSchema,
  documentsResponseSchema,
  errorBodySchema,
  healthResponseSchema,
  okSchema,
  searchResponseSchema,
} from "./schemas";

const ACCESS_KEY = "kb-access-code";
export const AUTH_REQUIRED_EVENT = "kb-auth-required";

export class ApiError extends Error {
  readonly status: number;
  constructor(status: number, message: string) {
    super(message);
    this.name = "ApiError";
    this.status = status;
  }
}

export function getStoredCode(): string {
  if (typeof window === "undefined") return "";
  try {
    return window.sessionStorage.getItem(ACCESS_KEY) ?? "";
  } catch {
    return "";
  }
}

export function storeCode(code: string): void {
  try {
    window.sessionStorage.setItem(ACCESS_KEY, code);
  } catch {
    /* storage can be unavailable (private mode); the code then lasts for this page only */
  }
}

export function clearCode(): void {
  try {
    window.sessionStorage.removeItem(ACCESS_KEY);
  } catch {
    /* ignore */
  }
}

async function request<S extends z.ZodTypeAny>(path: string, schema: S, init: RequestInit = {}): Promise<z.infer<S>> {
  const headers = new Headers(init.headers);
  const code = getStoredCode();
  if (code) headers.set("x-access-code", code);
  if (typeof init.body === "string") headers.set("Content-Type", "application/json");

  let response: Response;
  try {
    response = await fetch(path, { ...init, headers });
  } catch {
    throw new ApiError(0, "Network error. Check your connection and try again.");
  }

  const body: unknown = await response.json().catch(() => null);

  if (!response.ok) {
    if (response.status === 401) window.dispatchEvent(new Event(AUTH_REQUIRED_EVENT));
    const parsed = errorBodySchema.safeParse(body);
    throw new ApiError(response.status, parsed.success ? parsed.data.error : `Request failed (HTTP ${response.status}).`);
  }

  const result = schema.safeParse(body);
  if (!result.success) throw new ApiError(502, "The server returned an unexpected response.");
  return result.data;
}

const post = (body: unknown): RequestInit => ({ method: "POST", body: JSON.stringify(body) });

export const api = {
  accessRequired: async (): Promise<boolean> => (await request("/api/access", accessStatusSchema)).required,
  verifyCode: async (code: string): Promise<void> => {
    await request("/api/access", okSchema, post({ code }));
  },

  listDocuments: async () => (await request("/api/documents", documentsResponseSchema)).documents,
  uploadDocument: async (file: File) => {
    const form = new FormData();
    form.append("file", file);
    return (await request("/api/documents", documentResponseSchema, { method: "POST", body: form })).document;
  },
  deleteDocument: async (id: string): Promise<void> => {
    await request(`/api/documents/${id}`, okSchema, { method: "DELETE" });
  },

  listConversations: async () => (await request("/api/conversations", conversationsResponseSchema)).conversations,
  getConversation: (id: string) => request(`/api/conversations/${id}`, conversationDetailSchema),
  deleteConversation: async (id: string): Promise<void> => {
    await request(`/api/conversations/${id}`, okSchema, { method: "DELETE" });
  },

  chat: (input: { question: string; conversationId?: string; documentIds?: string[] }) =>
    request("/api/chat", chatResponseSchema, post(input)),
  search: async (input: { query: string; documentIds?: string[] }) =>
    (await request("/api/search", searchResponseSchema, post(input))).results,

  health: async (includeLlm: boolean) =>
    (await request(`/api/health${includeLlm ? "?llm=1" : ""}`, healthResponseSchema)).checks,
};
