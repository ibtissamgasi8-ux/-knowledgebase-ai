import { createClient, type SupabaseClient } from "@supabase/supabase-js";
import { getEnv } from "./env";
import { HttpError } from "./http";

let client: SupabaseClient | null = null;

/** Server-only client using the service-role key. Never import this from a client component. */
export function getSupabase(): SupabaseClient {
  if (client) return client;
  const env = getEnv();
  client = createClient(env.SUPABASE_URL, env.SUPABASE_SERVICE_ROLE_KEY, {
    auth: { persistSession: false, autoRefreshToken: false },
  });
  return client;
}

export function dbError(action: string, error: { message: string }): HttpError {
  console.error(`Database error while ${action}:`, error.message);
  return new HttpError(500, `Database error while ${action}: ${error.message}`);
}
