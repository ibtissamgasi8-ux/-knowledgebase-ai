import { z } from "zod";

/** The database column is halfvec(384); the embedding model must match. */
export const EMBEDDING_DIMENSIONS = 384;

const blankToUndefined = (value: unknown): unknown =>
  typeof value === "string" && value.trim() === "" ? undefined : value;

const optional = <T extends z.ZodTypeAny>(schema: T) =>
  z.preprocess(blankToUndefined, schema.optional());

const envSchema = z.object({
  SUPABASE_URL: z.string().url(),
  SUPABASE_SERVICE_ROLE_KEY: z.string().min(20),

  HF_API_TOKEN: z.string().min(8),
  HF_EMBEDDING_MODEL: z.preprocess(blankToUndefined, z.string().min(3).default("intfloat/multilingual-e5-small")),
  HF_EMBEDDING_URL: optional(z.string().url()),
  EMBEDDING_QUERY_PREFIX: z.string().default("query: "),
  EMBEDDING_PASSAGE_PREFIX: z.string().default("passage: "),

  OPENROUTER_API_KEY: z.string().min(8),
  OPENROUTER_MODEL: z.string().min(3),
  OPENROUTER_SITE_URL: optional(z.string().url()),

  APP_ACCESS_CODE: optional(z.string().min(6)),

  MAX_UPLOAD_BYTES: z.preprocess(blankToUndefined, z.coerce.number().int().min(1_000).max(1_000_000).default(150_000)),
  MAX_CHUNKS_PER_DOCUMENT: z.preprocess(blankToUndefined, z.coerce.number().int().min(1).max(1_000).default(200)),
  RAG_TOP_K: z.preprocess(blankToUndefined, z.coerce.number().int().min(1).max(20).default(6)),
  RAG_MIN_SIMILARITY: z.preprocess(blankToUndefined, z.coerce.number().min(0).max(1).default(0)),
});

export type AppEnv = z.infer<typeof envSchema>;

export class EnvError extends Error {
  readonly variables: string[];
  constructor(variables: string[]) {
    super(`Server is not configured. Missing or invalid environment variables: ${variables.join(", ")}.`);
    this.name = "EnvError";
    this.variables = variables;
  }
}

let cached: AppEnv | null = null;

/** Validated environment, read lazily so `next build` works without secrets. */
export function getEnv(): AppEnv {
  if (cached) return cached;
  const parsed = envSchema.safeParse(process.env);
  if (!parsed.success) {
    const names = [...new Set(parsed.error.issues.map((issue) => String(issue.path[0] ?? "unknown")))];
    throw new EnvError(names);
  }
  cached = parsed.data;
  return cached;
}
