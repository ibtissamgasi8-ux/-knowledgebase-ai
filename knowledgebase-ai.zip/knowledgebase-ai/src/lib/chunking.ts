/**
 * Structure-aware text chunking.
 *
 * - Splits on blank lines (paragraphs) and keeps paragraphs together up to `targetSize` characters.
 * - Paragraphs longer than `targetSize` are split on sentence boundaries, then on a hard limit.
 * - Markdown headings start a new chunk and are recorded as the chunk's `heading`.
 * - Consecutive chunks inside the same section share a small text overlap so context is not lost at the edges.
 */

export interface TextChunk {
  index: number;
  content: string;
  heading: string | null;
}

export interface ChunkOptions {
  markdown: boolean;
  /** Preferred maximum chunk length in characters. */
  targetSize?: number;
  /** Characters repeated from the end of the previous chunk. */
  overlap?: number;
}

const SENTENCE_BOUNDARY = /(?<=[.!?؟。！？])\s+/u;
const MARKDOWN_HEADING = /^#{1,6}\s+(.+?)\s*#*\s*$/;

function splitLongBlock(block: string, max: number): string[] {
  if (block.length <= max) return [block];

  const parts: string[] = [];
  let current = "";
  for (const sentence of block.split(SENTENCE_BOUNDARY)) {
    if (sentence.length > max) {
      if (current) {
        parts.push(current);
        current = "";
      }
      for (let start = 0; start < sentence.length; start += max) {
        parts.push(sentence.slice(start, start + max));
      }
      continue;
    }
    if (current && current.length + 1 + sentence.length > max) {
      parts.push(current);
      current = sentence;
    } else {
      current = current ? `${current} ${sentence}` : sentence;
    }
  }
  if (current) parts.push(current);
  return parts;
}

function overlapTail(text: string, size: number): string {
  if (size <= 0 || text.length <= size) return "";
  const tail = text.slice(-size);
  const firstSpace = tail.search(/\s/);
  return (firstSpace >= 0 ? tail.slice(firstSpace + 1) : tail).trim();
}

export function chunkText(raw: string, options: ChunkOptions): TextChunk[] {
  const targetSize = options.targetSize ?? 900;
  const overlap = options.overlap ?? 150;

  const text = raw.replace(/^\uFEFF/, "").replace(/\r\n?/g, "\n").trim();
  if (!text) return [];

  const blocks = text
    .split(/\n{2,}/)
    .map((block) => block.trim())
    .filter((block) => block.length > 0);

  const chunks: TextChunk[] = [];
  let heading: string | null = null;
  let buffer = "";
  let bufferHeading: string | null = null;
  let hasNewContent = false;

  const flush = (carryOverlap: boolean): void => {
    const previous = buffer;
    if (hasNewContent && previous.trim()) {
      chunks.push({ index: chunks.length, content: previous.trim(), heading: bufferHeading });
    }
    buffer = carryOverlap && hasNewContent ? overlapTail(previous, overlap) : "";
    hasNewContent = false;
    bufferHeading = heading;
  };

  for (const block of blocks) {
    if (options.markdown) {
      const firstLine = block.split("\n", 1)[0] ?? "";
      const match = MARKDOWN_HEADING.exec(firstLine);
      if (match?.[1]) {
        // A new section: close the current chunk without carrying overlap across sections.
        heading = match[1].trim();
        flush(false);
      }
    }

    for (const piece of splitLongBlock(block, targetSize)) {
      if (buffer && buffer.length + 2 + piece.length > targetSize && hasNewContent) {
        flush(true);
      }
      buffer = buffer ? `${buffer}\n\n${piece}` : piece;
      hasNewContent = true;
      if (bufferHeading === null) bufferHeading = heading;
    }
  }
  flush(false);

  return chunks;
}
