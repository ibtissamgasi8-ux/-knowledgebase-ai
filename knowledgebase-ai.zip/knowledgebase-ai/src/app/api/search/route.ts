import { jsonResponse, readJson, route } from "@/lib/http";
import { retrieveChunks, toSearchResults } from "@/lib/rag";
import { searchRequestSchema } from "@/lib/schemas";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

/** Pure semantic search: embeds the query and returns the closest chunks (no LLM call). */
export const POST = route(async (req) => {
  const body = searchRequestSchema.parse(await readJson(req));
  const rows = await retrieveChunks(body.query, { limit: body.limit, documentIds: body.documentIds });
  return jsonResponse({ results: toSearchResults(rows) });
});
