import { z } from "zod";
import { accessRequired, isCodeValid } from "@/lib/auth";
import { HttpError, jsonResponse, readJson, route } from "@/lib/http";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

const bodySchema = z.object({ code: z.string().max(200) });

/** Tells the UI whether an access code is needed. */
export const GET = route(
  async () => jsonResponse({ required: accessRequired() }),
  { public: true },
);

/** Verifies an access code without exposing it. */
export const POST = route(
  async (req) => {
    const { code } = bodySchema.parse(await readJson(req));
    if (!isCodeValid(code)) throw new HttpError(401, "Incorrect access code.");
    return jsonResponse({ ok: true as const });
  },
  { public: true },
);
