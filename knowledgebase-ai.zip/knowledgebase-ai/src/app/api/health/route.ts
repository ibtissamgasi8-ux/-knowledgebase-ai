import { embedTexts, toPgVector } from "@/lib/embeddings";
import { EMBEDDING_DIMENSIONS, EnvError, getEnv } from "@/lib/env";
import { jsonResponse, route } from "@/lib/http";
import { generateAnswer } from "@/lib/llm";
import type { HealthCheck } from "@/lib/schemas";
import { getSupabase } from "@/lib/supabase";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

async function check(name: string, run: () => Promise<string>): Promise<HealthCheck> {
  try {
    return { name, ok: true, detail: await run() };
  } catch (error) {
    return { name, ok: false, detail: error instanceof Error ? error.message : "Unknown error" };
  }
}

/**
 * Live diagnostics. Each check calls the real service.
 * Add ?llm=1 to also send a tiny test prompt to OpenRouter (uses a few tokens).
 */
export const GET = route(async (req) => {
  const includeLlm = new URL(req.url).searchParams.get("llm") === "1";
  const checks: HealthCheck[] = [];

  try {
    getEnv();
    checks.push({ name: "Environment variables", ok: true, detail: "All required variables are present and valid." });
  } catch (error) {
    const detail = error instanceof EnvError ? error.message : "Environment validation failed.";
    return jsonResponse({ checks: [{ name: "Environment variables", ok: false, detail }] });
  }

  checks.push(
    await check("Database tables", async () => {
      const { error } = await getSupabase().from("documents").select("id").limit(1);
      if (error) throw new Error(`${error.message}. Did you run supabase/migrations/0001_init.sql?`);
      return "Connected; the documents table is reachable.";
    }),
  );

  let probeVector: number[] | null = null;
  checks.push(
    await check("Embeddings (Hugging Face)", async () => {
      const [vector] = await embedTexts(["health check"], "query");
      if (!vector) throw new Error("No vector returned.");
      probeVector = vector;
      return `Model returned a ${vector.length}-dimension vector (expected ${EMBEDDING_DIMENSIONS}).`;
    }),
  );

  checks.push(
    await check("Vector search (pgvector)", async () => {
      if (!probeVector) throw new Error("Skipped because embeddings failed.");
      const { error } = await getSupabase().rpc("match_chunks", {
        query_embedding: toPgVector(probeVector),
        match_count: 1,
        min_similarity: 0,
        filter_document_ids: null,
      });
      if (error) throw new Error(`${error.message}. Did you run supabase/migrations/0001_init.sql?`);
      return "match_chunks() executed successfully.";
    }),
  );

  if (includeLlm) {
    checks.push(
      await check("Chat model (OpenRouter)", async () => {
        const reply = await generateAnswer([{ role: "user", content: "Reply with the single word: OK" }], 8);
        return `Model replied: ${reply.slice(0, 40)}`;
      }),
    );
  }

  return jsonResponse({ checks });
});
