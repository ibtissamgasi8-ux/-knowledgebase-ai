import { z } from "zod";
import { HttpError, jsonResponse, route } from "@/lib/http";
import { conversationSchema, messageSchema, uuidSchema } from "@/lib/schemas";
import { dbError, getSupabase } from "@/lib/supabase";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

interface Context {
  params: Promise<{ id: string }>;
}

export const GET = route<Context>(async (_req, ctx) => {
  const id = uuidSchema.parse((await ctx.params).id);
  const supabase = getSupabase();

  const conversation = await supabase
    .from("conversations")
    .select("id,title,created_at,updated_at")
    .eq("id", id)
    .maybeSingle();
  if (conversation.error) throw dbError("loading the conversation", conversation.error);
  if (!conversation.data) throw new HttpError(404, "Conversation not found.");

  const messages = await supabase
    .from("messages")
    .select("id,conversation_id,role,content,sources,created_at")
    .eq("conversation_id", id)
    .order("created_at", { ascending: true });
  if (messages.error) throw dbError("loading messages", messages.error);

  return jsonResponse({
    conversation: conversationSchema.parse(conversation.data),
    messages: z.array(messageSchema).parse(messages.data ?? []),
  });
});

export const DELETE = route<Context>(async (_req, ctx) => {
  const id = uuidSchema.parse((await ctx.params).id);
  const { data, error } = await getSupabase().from("conversations").delete().eq("id", id).select("id");
  if (error) throw dbError("deleting the conversation", error);
  if (!data || data.length === 0) throw new HttpError(404, "Conversation not found.");
  return jsonResponse({ ok: true as const });
});
