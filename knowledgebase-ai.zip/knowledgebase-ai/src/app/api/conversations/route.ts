import { z } from "zod";
import { jsonResponse, route } from "@/lib/http";
import { conversationSchema } from "@/lib/schemas";
import { dbError, getSupabase } from "@/lib/supabase";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

export const GET = route(async () => {
  const { data, error } = await getSupabase()
    .from("conversations")
    .select("id,title,created_at,updated_at")
    .order("updated_at", { ascending: false })
    .limit(50);
  if (error) throw dbError("listing conversations", error);
  return jsonResponse({ conversations: z.array(conversationSchema).parse(data ?? []) });
});
