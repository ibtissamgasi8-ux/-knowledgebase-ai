import { HttpError, jsonResponse, route } from "@/lib/http";
import { uuidSchema } from "@/lib/schemas";
import { dbError, getSupabase } from "@/lib/supabase";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

interface Context {
  params: Promise<{ id: string }>;
}

/** Deletes a document; its chunks are removed by ON DELETE CASCADE. */
export const DELETE = route<Context>(async (_req, ctx) => {
  const id = uuidSchema.parse((await ctx.params).id);
  const { data, error } = await getSupabase().from("documents").delete().eq("id", id).select("id");
  if (error) throw dbError("deleting the document", error);
  if (!data || data.length === 0) throw new HttpError(404, "Document not found.");
  return jsonResponse({ ok: true as const });
});
