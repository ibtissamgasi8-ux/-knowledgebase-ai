import { createHash } from "node:crypto";
import { z } from "zod";
import { chunkText } from "@/lib/chunking";
import { embedTexts, toPgVector } from "@/lib/embeddings";
import { getEnv } from "@/lib/env";
import { HttpError, jsonResponse, route } from "@/lib/http";
import { documentSchema } from "@/lib/schemas";
import { dbError, getSupabase } from "@/lib/supabase";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

const DOCUMENT_COLUMNS = "id,title,filename,file_type,size_bytes,chunk_count,created_at";
const INSERT_BATCH_SIZE = 50;

export const GET = route(async () => {
  const { data, error } = await getSupabase()
    .from("documents")
    .select(DOCUMENT_COLUMNS)
    .order("created_at", { ascending: false });
  if (error) throw dbError("listing documents", error);
  return jsonResponse({ documents: z.array(documentSchema).parse(data ?? []) });
});

export const POST = route(async (req) => {
  const env = getEnv();

  const form = await req.formData().catch(() => {
    throw new HttpError(400, "Upload must be sent as multipart form data.");
  });
  const file = form.get("file");
  if (!(file instanceof File)) throw new HttpError(400, "No file received.");

  const filename = file.name.trim() || "document.txt";
  const extension = /\.(txt|md|markdown)$/i.exec(filename)?.[1]?.toLowerCase();
  if (!extension) throw new HttpError(400, "Only .txt, .md and .markdown files are supported.");
  const fileType = extension === "txt" ? "txt" : "md";

  if (file.size === 0) throw new HttpError(400, "The file is empty.");
  if (file.size > env.MAX_UPLOAD_BYTES) {
    throw new HttpError(413, `File is too large. The limit is ${Math.round(env.MAX_UPLOAD_BYTES / 1000)} KB.`);
  }

  let text: string;
  try {
    text = new TextDecoder("utf-8", { fatal: true }).decode(await file.arrayBuffer());
  } catch {
    throw new HttpError(400, "The file is not valid UTF-8 text. Re-save it as UTF-8 and try again.");
  }
  if (text.includes("\u0000")) throw new HttpError(400, "The file looks like binary data, not text.");

  const chunks = chunkText(text, { markdown: fileType === "md" });
  if (chunks.length === 0) throw new HttpError(400, "No readable text found in the file.");
  if (chunks.length > env.MAX_CHUNKS_PER_DOCUMENT) {
    throw new HttpError(
      413,
      `This file produces ${chunks.length} chunks; the limit is ${env.MAX_CHUNKS_PER_DOCUMENT}. Split the file into smaller parts.`,
    );
  }

  const supabase = getSupabase();
  const contentHash = createHash("sha256").update(text.trim()).digest("hex");

  const duplicate = await supabase
    .from("documents")
    .select("title")
    .eq("content_hash", contentHash)
    .limit(1);
  if (duplicate.error) throw dbError("checking for duplicates", duplicate.error);
  const existing = duplicate.data?.[0] as { title?: string } | undefined;
  if (existing) {
    throw new HttpError(409, `This file was already uploaded as “${existing.title ?? "another document"}”.`);
  }

  // Embed first: if the embedding service fails, nothing is written to the database.
  const vectors = await embedTexts(chunks.map((chunk) => chunk.content), "passage");
  if (vectors.length !== chunks.length) throw new HttpError(502, "Embedding count did not match chunk count.");

  const title =
    filename.replace(/\.(txt|md|markdown)$/i, "").replace(/[_-]+/g, " ").trim().slice(0, 120) || "Untitled";

  const inserted = await supabase
    .from("documents")
    .insert({
      title,
      filename: filename.slice(0, 200),
      file_type: fileType,
      size_bytes: file.size,
      chunk_count: chunks.length,
      content_hash: contentHash,
    })
    .select(DOCUMENT_COLUMNS)
    .single();
  if (inserted.error) throw dbError("saving the document", inserted.error);
  const document = documentSchema.parse(inserted.data);

  const rows = chunks.map((chunk, index) => ({
    document_id: document.id,
    chunk_index: chunk.index,
    heading: chunk.heading,
    content: chunk.content,
    embedding: toPgVector(vectors[index] ?? []),
  }));

  for (let start = 0; start < rows.length; start += INSERT_BATCH_SIZE) {
    const { error } = await supabase.from("chunks").insert(rows.slice(start, start + INSERT_BATCH_SIZE));
    if (error) {
      // Roll back so a half-indexed document never appears in the library.
      await supabase.from("documents").delete().eq("id", document.id);
      throw dbError("saving chunks", error);
    }
  }

  return jsonResponse({ document }, 201);
});
