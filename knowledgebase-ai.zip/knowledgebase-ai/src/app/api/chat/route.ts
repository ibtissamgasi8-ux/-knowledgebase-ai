import { z } from "zod";
import { HttpError, jsonResponse, readJson, route } from "@/lib/http";
import type { ChatMessage } from "@/lib/llm";
import { answerQuestion } from "@/lib/rag";
import { chatRequestSchema, conversationSchema, messageSchema } from "@/lib/schemas";
import { dbError, getSupabase } from "@/lib/supabase";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

const CONVERSATION_COLUMNS = "id,title,created_at,updated_at";
const MESSAGE_COLUMNS = "id,conversation_id,role,content,sources,created_at";

const historyRowSchema = z.object({ role: z.enum(["user", "assistant"]), content: z.string() });

export const POST = route(async (req) => {
  const body = chatRequestSchema.parse(await readJson(req));
  const supabase = getSupabase();
  const askedAt = new Date().toISOString();

  // Previous turns give the model conversational context for follow-up questions.
  let history: ChatMessage[] = [];
  if (body.conversationId) {
    const found = await supabase.from("conversations").select("id").eq("id", body.conversationId).maybeSingle();
    if (found.error) throw dbError("loading the conversation", found.error);
    if (!found.data) throw new HttpError(404, "Conversation not found.");

    const existing = await supabase
      .from("messages")
      .select("role,content")
      .eq("conversation_id", body.conversationId)
      .order("created_at", { ascending: false })
      .limit(6);
    if (existing.error) throw dbError("loading the conversation", existing.error);
    history = z
      .array(historyRowSchema)
      .parse(existing.data ?? [])
      .reverse()
      .map((row) => ({ role: row.role, content: row.content }));
  }

  // Do the slow, fallible work first so a failure never leaves a dangling question in the history.
  const { answer, sources } = await answerQuestion(body.question, history, body.documentIds);

  let conversationId = body.conversationId;
  if (!conversationId) {
    const created = await supabase
      .from("conversations")
      .insert({ title: body.question.slice(0, 60) })
      .select("id")
      .single();
    if (created.error) throw dbError("creating the conversation", created.error);
    conversationId = z.object({ id: z.string().uuid() }).parse(created.data).id;
  }

  const insertedMessages = await supabase
    .from("messages")
    .insert([
      { conversation_id: conversationId, role: "user", content: body.question, sources: [], created_at: askedAt },
      {
        conversation_id: conversationId,
        role: "assistant",
        content: answer,
        sources,
        created_at: new Date().toISOString(),
      },
    ])
    .select(MESSAGE_COLUMNS);
  if (insertedMessages.error) throw dbError("saving messages", insertedMessages.error);

  const messages = z.array(messageSchema).parse(insertedMessages.data ?? []);
  const userMessage = messages.find((message) => message.role === "user");
  const assistantMessage = messages.find((message) => message.role === "assistant");
  if (!userMessage || !assistantMessage) throw new HttpError(500, "Messages were not saved correctly.");

  const touched = await supabase
    .from("conversations")
    .update({ updated_at: new Date().toISOString() })
    .eq("id", conversationId)
    .select(CONVERSATION_COLUMNS)
    .single();
  if (touched.error) {
    if (!body.conversationId) throw dbError("updating the conversation", touched.error);
    throw new HttpError(404, "Conversation not found.");
  }

  return jsonResponse({
    conversation: conversationSchema.parse(touched.data),
    userMessage,
    assistantMessage,
  });
});
