"use client";

import { useCallback, useEffect, useMemo, useState } from "react";
import { api, ApiError, AUTH_REQUIRED_EVENT, clearCode, getStoredCode } from "@/lib/client-api";
import type { Conversation, DocumentRow, Message } from "@/lib/schemas";
import { AccessGate } from "./AccessGate";
import { ChatPanel } from "./ChatPanel";
import { ConversationList } from "./ConversationList";
import { DocumentPanel, type Notice } from "./DocumentPanel";
import { ChatIcon, FileIcon, LogoMark, PulseIcon } from "./icons";
import { SearchPanel } from "./SearchPanel";
import { StatusDialog } from "./StatusDialog";

type GateStatus = "checking" | "locked" | "error" | "ready";
type View = "chat" | "library";
type Mode = "ask" | "search";

const messageOf = (error: unknown, fallback: string): string =>
  error instanceof ApiError ? error.message : fallback;

export function Dashboard() {
  const [gate, setGate] = useState<{ status: GateStatus; message: string | null }>({ status: "checking", message: null });

  const [documents, setDocuments] = useState<DocumentRow[]>([]);
  const [loadingDocuments, setLoadingDocuments] = useState(true);
  const [uploading, setUploading] = useState(false);
  const [selected, setSelected] = useState<ReadonlySet<string>>(new Set());
  const [notice, setNotice] = useState<Notice | null>(null);

  const [conversations, setConversations] = useState<Conversation[]>([]);
  const [activeId, setActiveId] = useState<string | null>(null);
  const [messages, setMessages] = useState<Message[]>([]);
  const [loadingConversation, setLoadingConversation] = useState(false);
  const [pendingQuestion, setPendingQuestion] = useState<string | null>(null);
  const [chatError, setChatError] = useState<string | null>(null);

  const [view, setView] = useState<View>("chat");
  const [mode, setMode] = useState<Mode>("ask");
  const [showStatus, setShowStatus] = useState(false);

  /* ---------- Access gate ---------- */

  useEffect(() => {
    let cancelled = false;
    async function boot(): Promise<void> {
      try {
        const required = await api.accessRequired();
        if (cancelled) return;
        if (!required) {
          setGate({ status: "ready", message: null });
          return;
        }
        if (getStoredCode()) {
          try {
            await api.verifyCode(getStoredCode());
            if (!cancelled) setGate({ status: "ready", message: null });
            return;
          } catch {
            clearCode();
          }
        }
        if (!cancelled) setGate({ status: "locked", message: null });
      } catch (error) {
        if (!cancelled) setGate({ status: "error", message: messageOf(error, "The server could not be reached.") });
      }
    }
    void boot();

    const onAuthRequired = (): void => {
      clearCode();
      setGate({ status: "locked", message: null });
    };
    window.addEventListener(AUTH_REQUIRED_EVENT, onAuthRequired);
    return () => {
      cancelled = true;
      window.removeEventListener(AUTH_REQUIRED_EVENT, onAuthRequired);
    };
  }, []);

  /* ---------- Data loading ---------- */

  const refreshDocuments = useCallback(async (): Promise<void> => {
    try {
      setDocuments(await api.listDocuments());
    } catch (error) {
      setNotice({ kind: "error", text: messageOf(error, "Could not load documents.") });
    } finally {
      setLoadingDocuments(false);
    }
  }, []);

  const refreshConversations = useCallback(async (): Promise<void> => {
    try {
      setConversations(await api.listConversations());
    } catch (error) {
      setNotice({ kind: "error", text: messageOf(error, "Could not load conversations.") });
    }
  }, []);

  useEffect(() => {
    if (gate.status !== "ready") return;
    void refreshDocuments();
    void refreshConversations();
  }, [gate.status, refreshDocuments, refreshConversations]);

  const selectedIds = useMemo(
    () => documents.filter((document) => selected.has(document.id)).map((document) => document.id),
    [documents, selected],
  );

  const scopeLabel =
    documents.length === 0
      ? "no documents"
      : selectedIds.length > 0
        ? `${selectedIds.length} selected document${selectedIds.length > 1 ? "s" : ""}`
        : "all documents";

  /* ---------- Documents ---------- */

  async function handleUpload(files: File[]): Promise<void> {
    setUploading(true);
    setNotice(null);
    const indexed: string[] = [];
    const failed: string[] = [];
    for (const file of files) {
      try {
        indexed.push((await api.uploadDocument(file)).title);
      } catch (error) {
        failed.push(`${file.name}: ${messageOf(error, "upload failed.")}`);
      }
    }
    await refreshDocuments();
    setUploading(false);
    const parts: string[] = [];
    if (indexed.length > 0) parts.push(`Indexed ${indexed.join(", ")}.`);
    if (failed.length > 0) parts.push(failed.join(" "));
    setNotice({ kind: failed.length > 0 ? "error" : "success", text: parts.join(" ") });
  }

  async function handleDeleteDocument(document: DocumentRow): Promise<void> {
    if (!window.confirm(`Delete “${document.title}” and its ${document.chunk_count} indexed chunks?`)) return;
    try {
      await api.deleteDocument(document.id);
      setSelected((previous) => {
        const next = new Set(previous);
        next.delete(document.id);
        return next;
      });
      await refreshDocuments();
      setNotice({ kind: "success", text: `Deleted “${document.title}”.` });
    } catch (error) {
      setNotice({ kind: "error", text: messageOf(error, "Could not delete the document.") });
    }
  }

  function toggleSelected(id: string): void {
    setSelected((previous) => {
      const next = new Set(previous);
      if (next.has(id)) next.delete(id);
      else next.add(id);
      return next;
    });
  }

  /* ---------- Conversations ---------- */

  async function openConversation(id: string): Promise<void> {
    setView("chat");
    setMode("ask");
    setActiveId(id);
    setChatError(null);
    setLoadingConversation(true);
    setMessages([]);
    try {
      const detail = await api.getConversation(id);
      setMessages(detail.messages);
    } catch (error) {
      setChatError(messageOf(error, "Could not load the conversation."));
    } finally {
      setLoadingConversation(false);
    }
  }

  function startNewChat(): void {
    setActiveId(null);
    setMessages([]);
    setChatError(null);
    setView("chat");
    setMode("ask");
  }

  async function handleDeleteConversation(conversation: Conversation): Promise<void> {
    if (!window.confirm(`Delete the conversation “${conversation.title}”?`)) return;
    try {
      await api.deleteConversation(conversation.id);
      if (conversation.id === activeId) startNewChat();
      await refreshConversations();
    } catch (error) {
      setNotice({ kind: "error", text: messageOf(error, "Could not delete the conversation.") });
    }
  }

  async function handleSend(question: string): Promise<boolean> {
    setChatError(null);
    setPendingQuestion(question);
    try {
      const result = await api.chat({
        question,
        conversationId: activeId ?? undefined,
        documentIds: selectedIds.length > 0 ? selectedIds : undefined,
      });
      setActiveId(result.conversation.id);
      setMessages((previous) => [...previous, result.userMessage, result.assistantMessage]);
      void refreshConversations();
      return true;
    } catch (error) {
      setChatError(messageOf(error, "Something went wrong. Please try again."));
      return false;
    } finally {
      setPendingQuestion(null);
    }
  }

  /* ---------- Render ---------- */

  if (gate.status !== "ready") {
    return (
      <AccessGate
        status={gate.status}
        message={gate.message}
        onUnlocked={() => setGate({ status: "ready", message: null })}
      />
    );
  }

  return (
    <div className="flex h-dvh flex-col bg-white">
      <header className="flex items-center justify-between border-b border-slate-200 px-4 pb-3 pt-safe md:px-6">
        <div className="flex items-center gap-3 pt-3">
          <LogoMark className="h-9 w-9 shrink-0" />
          <div className="leading-tight">
            <h1 className="text-base font-semibold tracking-tight">KnowledgeBase AI</h1>
            <p className="hidden text-xs text-slate-500 sm:block">Intelligent Document Search &amp; RAG Assistant</p>
          </div>
        </div>
        <button
          type="button"
          onClick={() => setShowStatus(true)}
          className="mt-3 flex items-center gap-2 rounded-xl border border-slate-200 px-3 py-2 text-xs font-semibold text-slate-700 hover:border-brand-500 hover:text-brand-700"
        >
          <PulseIcon width={16} height={16} />
          System check
        </button>
      </header>

      <div className="flex min-h-0 flex-1">
        <aside
          className={`${view === "library" ? "flex" : "hidden"} min-h-0 w-full shrink-0 flex-col overflow-y-auto border-slate-200 md:flex md:w-[340px] md:border-r`}
        >
          <DocumentPanel
            documents={documents}
            loading={loadingDocuments}
            uploading={uploading}
            selected={selected}
            notice={notice}
            onToggle={toggleSelected}
            onClearSelection={() => setSelected(new Set())}
            onUpload={(files) => void handleUpload(files)}
            onDelete={(document) => void handleDeleteDocument(document)}
            onDismissNotice={() => setNotice(null)}
          />
          <div className="mt-4 border-t border-slate-200" />
          <ConversationList
            conversations={conversations}
            activeId={activeId}
            onSelect={(id) => void openConversation(id)}
            onNew={startNewChat}
            onDelete={(conversation) => void handleDeleteConversation(conversation)}
          />
        </aside>

        <main className={`${view === "chat" ? "flex" : "hidden"} min-h-0 min-w-0 flex-1 flex-col md:flex`}>
          <div className="flex items-center justify-between gap-3 border-b border-slate-200 px-4 py-2.5 md:px-8">
            <div role="tablist" aria-label="Mode" className="inline-flex rounded-xl bg-slate-100 p-1">
              {(["ask", "search"] as const).map((item) => (
                <button
                  key={item}
                  type="button"
                  role="tab"
                  aria-selected={mode === item}
                  onClick={() => setMode(item)}
                  className={`rounded-lg px-4 py-1.5 text-sm font-semibold transition ${
                    mode === item ? "bg-white text-brand-700 shadow-sm" : "text-slate-600"
                  }`}
                >
                  {item === "ask" ? "Ask AI" : "Search"}
                </button>
              ))}
            </div>
            <p className="truncate text-xs text-slate-500">Using {scopeLabel}</p>
          </div>

          {mode === "ask" ? (
            <ChatPanel
              messages={messages}
              pendingQuestion={pendingQuestion}
              loadingConversation={loadingConversation}
              error={chatError}
              hasDocuments={documents.length > 0}
              onSend={handleSend}
              onDismissError={() => setChatError(null)}
              onOpenLibrary={() => setView("library")}
            />
          ) : (
            <SearchPanel documentIds={selectedIds} />
          )}
        </main>
      </div>

      <nav aria-label="Primary" className="grid grid-cols-2 border-t border-slate-200 bg-white pb-safe md:hidden">
        {(
          [
            { id: "chat", label: "Chat", Icon: ChatIcon },
            { id: "library", label: "Library", Icon: FileIcon },
          ] as const
        ).map(({ id, label, Icon }) => (
          <button
            key={id}
            type="button"
            onClick={() => setView(id)}
            aria-current={view === id ? "page" : undefined}
            className={`flex flex-col items-center gap-0.5 py-2.5 text-xs font-semibold ${
              view === id ? "text-brand-700" : "text-slate-500"
            }`}
          >
            <Icon />
            {label}
          </button>
        ))}
      </nav>

      {showStatus && <StatusDialog onClose={() => setShowStatus(false)} />}
    </div>
  );
}
