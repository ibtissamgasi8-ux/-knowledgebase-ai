"use client";

import { useState, type FormEvent } from "react";
import { api, ApiError } from "@/lib/client-api";
import type { SearchResult } from "@/lib/schemas";
import { SearchIcon } from "./icons";

export function SearchPanel({ documentIds }: { documentIds: string[] }) {
  const [query, setQuery] = useState("");
  const [results, setResults] = useState<SearchResult[] | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [searchedFor, setSearchedFor] = useState("");

  async function submit(event: FormEvent<HTMLFormElement>): Promise<void> {
    event.preventDefault();
    const text = query.trim();
    if (!text || loading) return;
    setLoading(true);
    setError(null);
    try {
      setResults(await api.search({ query: text, documentIds: documentIds.length > 0 ? documentIds : undefined }));
      setSearchedFor(text);
    } catch (caught) {
      setError(caught instanceof ApiError ? caught.message : "Search failed.");
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="flex min-h-0 flex-1 flex-col">
      <form onSubmit={submit} className="border-b border-slate-200 px-4 py-3 md:px-8">
        <div className="mx-auto flex w-full max-w-3xl items-center gap-2 rounded-2xl border border-slate-300 p-2 focus-within:border-brand-600">
          <SearchIcon className="ml-2 shrink-0 text-slate-400" />
          <label htmlFor="search-query" className="sr-only">
            Search passages
          </label>
          <input
            id="search-query"
            type="search"
            value={query}
            maxLength={500}
            onChange={(event) => setQuery(event.target.value)}
            placeholder="Search by meaning, not just keywords"
            className="min-w-0 flex-1 bg-transparent px-1 py-2 text-base outline-none focus-visible:ring-0 focus-visible:ring-offset-0"
          />
          <button
            type="submit"
            disabled={loading || query.trim().length === 0}
            className="rounded-xl bg-brand-600 px-4 py-2 text-sm font-semibold text-white hover:bg-brand-700 disabled:opacity-40"
          >
            {loading ? "Searching…" : "Search"}
          </button>
        </div>
      </form>

      <div className="min-h-0 flex-1 overflow-y-auto px-4 py-5 md:px-8">
        <div className="mx-auto w-full max-w-3xl space-y-3">
          {error && (
            <div role="alert" className="rounded-lg border border-red-200 bg-red-50 px-3 py-2 text-sm text-red-800">
              {error}
            </div>
          )}

          {results === null && !error && (
            <p className="py-10 text-center text-sm text-slate-500">
              Semantic search finds the passages closest in meaning to your query, ranked by similarity.
            </p>
          )}

          {results !== null && results.length === 0 && (
            <p className="py-10 text-center text-sm text-slate-500">No passages found for “{searchedFor}”.</p>
          )}

          {results?.map((result, index) => (
            <article key={result.chunkId} className="rounded-xl border border-slate-200 px-4 py-3">
              <div className="flex items-start justify-between gap-3">
                <p className="min-w-0 text-sm font-semibold">
                  {index + 1}. {result.title}
                  {result.heading ? <span className="font-normal text-slate-500"> — {result.heading}</span> : null}
                </p>
                <span className="shrink-0 rounded-full bg-brand-50 px-2 py-0.5 text-xs font-semibold text-brand-700">
                  {Math.round(result.similarity * 100)}%
                </span>
              </div>
              <p className="mt-2 whitespace-pre-wrap text-sm leading-6 text-slate-700">{result.content}</p>
            </article>
          ))}
        </div>
      </div>
    </div>
  );
}
