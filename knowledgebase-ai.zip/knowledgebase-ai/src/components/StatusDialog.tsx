"use client";

import { useEffect, useState } from "react";
import { api, ApiError } from "@/lib/client-api";
import type { HealthCheck } from "@/lib/schemas";
import { CheckIcon, CloseIcon } from "./icons";

export function StatusDialog({ onClose }: { onClose: () => void }) {
  const [checks, setChecks] = useState<HealthCheck[] | null>(null);
  const [running, setRunning] = useState(false);
  const [includeLlm, setIncludeLlm] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const onKey = (event: KeyboardEvent): void => {
      if (event.key === "Escape") onClose();
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [onClose]);

  async function run(): Promise<void> {
    setRunning(true);
    setError(null);
    try {
      setChecks(await api.health(includeLlm));
    } catch (caught) {
      setError(caught instanceof ApiError ? caught.message : "System check failed.");
    } finally {
      setRunning(false);
    }
  }

  return (
    <div className="fixed inset-0 z-50 flex items-end justify-center bg-slate-900/40 p-0 sm:items-center sm:p-4" onClick={onClose}>
      <div
        role="dialog"
        aria-modal="true"
        aria-labelledby="status-title"
        className="max-h-[90dvh] w-full max-w-lg overflow-y-auto rounded-t-2xl bg-white p-5 pb-safe sm:rounded-2xl"
        onClick={(event) => event.stopPropagation()}
      >
        <div className="flex items-center justify-between">
          <h2 id="status-title" className="text-lg font-semibold">
            System check
          </h2>
          <button type="button" onClick={onClose} aria-label="Close" className="rounded-lg p-2 hover:bg-slate-100">
            <CloseIcon />
          </button>
        </div>
        <p className="mt-1 text-sm text-slate-500">
          Runs live calls to your database, embedding model and vector search to confirm everything is configured.
        </p>

        <label className="mt-4 flex items-center gap-2 text-sm">
          <input
            type="checkbox"
            checked={includeLlm}
            onChange={(event) => setIncludeLlm(event.target.checked)}
            className="h-4 w-4 accent-brand-600"
          />
          Also test the chat model (uses a few tokens)
        </label>

        <button
          type="button"
          onClick={() => void run()}
          disabled={running}
          className="mt-4 w-full rounded-xl bg-brand-600 px-4 py-3 text-sm font-semibold text-white hover:bg-brand-700 disabled:opacity-60"
        >
          {running ? "Running checks…" : "Run checks"}
        </button>

        {error && (
          <p role="alert" className="mt-4 rounded-lg border border-red-200 bg-red-50 px-3 py-2 text-sm text-red-800">
            {error}
          </p>
        )}

        {checks && (
          <ul className="mt-4 space-y-2">
            {checks.map((check) => (
              <li key={check.name} className="flex gap-3 rounded-xl border border-slate-200 px-3 py-3">
                <span
                  className={`mt-0.5 flex h-5 w-5 shrink-0 items-center justify-center rounded-full text-white ${
                    check.ok ? "bg-emerald-600" : "bg-red-600"
                  }`}
                >
                  {check.ok ? <CheckIcon width={12} height={12} strokeWidth={3} /> : <CloseIcon width={12} height={12} strokeWidth={3} />}
                </span>
                <div className="min-w-0">
                  <p className="text-sm font-semibold">{check.name}</p>
                  <p className="break-words text-xs text-slate-600">{check.detail}</p>
                </div>
              </li>
            ))}
          </ul>
        )}
      </div>
    </div>
  );
}
