"use client";

import { useRef, type ChangeEvent } from "react";
import type { DocumentRow } from "@/lib/schemas";
import { CloseIcon, FileIcon, TrashIcon, UploadIcon } from "./icons";

export interface Notice {
  kind: "error" | "success";
  text: string;
}

interface DocumentPanelProps {
  documents: DocumentRow[];
  loading: boolean;
  uploading: boolean;
  selected: ReadonlySet<string>;
  notice: Notice | null;
  onToggle: (id: string) => void;
  onClearSelection: () => void;
  onUpload: (files: File[]) => void;
  onDelete: (document: DocumentRow) => void;
  onDismissNotice: () => void;
}

function formatBytes(bytes: number): string {
  if (bytes < 1024) return `${bytes} B`;
  return `${(bytes / 1024).toFixed(bytes < 10_240 ? 1 : 0)} KB`;
}

const dateFormat = new Intl.DateTimeFormat(undefined, { dateStyle: "medium" });

export function DocumentPanel(props: DocumentPanelProps) {
  const { documents, loading, uploading, selected, notice } = props;
  const inputRef = useRef<HTMLInputElement>(null);

  function handleFiles(event: ChangeEvent<HTMLInputElement>): void {
    const files = Array.from(event.target.files ?? []);
    event.target.value = "";
    if (files.length > 0) props.onUpload(files);
  }

  return (
    <section aria-labelledby="documents-heading" className="px-4 pt-4">
      <div className="flex items-center justify-between">
        <h2 id="documents-heading" className="text-sm font-semibold text-slate-900">
          Documents
        </h2>
        {selected.size > 0 && (
          <button
            type="button"
            onClick={props.onClearSelection}
            className="text-xs font-medium text-brand-700 hover:underline"
          >
            Use all documents
          </button>
        )}
      </div>

      <input
        ref={inputRef}
        type="file"
        accept=".txt,.md,.markdown,text/plain,text/markdown"
        multiple
        className="hidden"
        onChange={handleFiles}
      />
      <button
        type="button"
        onClick={() => inputRef.current?.click()}
        disabled={uploading}
        className="mt-3 flex w-full items-center justify-center gap-2 rounded-xl border border-dashed border-brand-200 bg-brand-50 px-4 py-4 text-sm font-semibold text-brand-700 transition hover:border-brand-500 disabled:opacity-60"
      >
        <UploadIcon />
        {uploading ? "Indexing document…" : "Upload TXT or Markdown"}
      </button>

      {notice && (
        <div
          role={notice.kind === "error" ? "alert" : "status"}
          className={`mt-3 flex items-start gap-2 rounded-lg border px-3 py-2 text-sm ${
            notice.kind === "error"
              ? "border-red-200 bg-red-50 text-red-800"
              : "border-emerald-200 bg-emerald-50 text-emerald-800"
          }`}
        >
          <span className="flex-1">{notice.text}</span>
          <button type="button" onClick={props.onDismissNotice} aria-label="Dismiss message" className="mt-0.5 shrink-0">
            <CloseIcon width={16} height={16} />
          </button>
        </div>
      )}

      <ul className="mt-3 space-y-1.5">
        {loading && documents.length === 0 && <li className="py-6 text-center text-sm text-slate-500">Loading documents…</li>}

        {!loading && documents.length === 0 && (
          <li className="rounded-xl border border-slate-200 px-4 py-6 text-center">
            <FileIcon className="mx-auto text-slate-400" width={28} height={28} />
            <p className="mt-2 text-sm font-medium">No documents yet</p>
            <p className="mt-1 text-xs text-slate-500">Upload a .txt or .md file to start asking questions about it.</p>
          </li>
        )}

        {documents.map((doc) => {
          const checked = selected.has(doc.id);
          return (
            <li
              key={doc.id}
              className={`flex items-center gap-3 rounded-xl border px-3 py-2.5 ${
                checked ? "border-brand-500 bg-brand-50" : "border-slate-200"
              }`}
            >
              <input
                type="checkbox"
                checked={checked}
                onChange={() => props.onToggle(doc.id)}
                aria-label={`Only use “${doc.title}” when answering`}
                className="h-5 w-5 shrink-0 accent-brand-600"
              />
              <div className="min-w-0 flex-1">
                <p className="truncate text-sm font-medium">{doc.title}</p>
                <p className="text-xs text-slate-500">
                  {doc.chunk_count} chunks · {formatBytes(doc.size_bytes)} · {dateFormat.format(new Date(doc.created_at))}
                </p>
              </div>
              <button
                type="button"
                onClick={() => props.onDelete(doc)}
                aria-label={`Delete ${doc.title}`}
                className="shrink-0 rounded-lg p-2 text-slate-500 hover:bg-red-50 hover:text-red-700"
              >
                <TrashIcon width={18} height={18} />
              </button>
            </li>
          );
        })}
      </ul>
      {documents.length > 0 && (
        <p className="mt-2 text-xs text-slate-500">Tick documents to limit answers and search to them.</p>
      )}
    </section>
  );
}
