"use client";

import { useEffect, useRef, useState, type KeyboardEvent } from "react";
import type { Message, Source } from "@/lib/schemas";
import { CloseIcon, FileIcon, SendIcon } from "./icons";

interface ChatPanelProps {
  messages: Message[];
  pendingQuestion: string | null;
  loadingConversation: boolean;
  error: string | null;
  hasDocuments: boolean;
  onSend: (question: string) => Promise<boolean>;
  onDismissError: () => void;
  onOpenLibrary: () => void;
}

const SUGGESTIONS = [
  "Summarize the main points of my documents.",
  "What topics do my documents cover?",
  "List any dates, names or numbers that are mentioned.",
];

function AnswerText({ text, sources }: { text: string; sources: Source[] }) {
  const parts = text.split(/(\[\d{1,2}\])/g);
  return (
    <p className="whitespace-pre-wrap text-[15px] leading-7 text-slate-800">
      {parts.map((part, index) => {
        const match = /^\[(\d{1,2})\]$/.exec(part);
        const source = match ? sources.find((item) => item.ref === Number(match[1])) : undefined;
        if (!source) return <span key={index}>{part}</span>;
        return (
          <sup key={index} title={source.title} className="mx-0.5 rounded bg-brand-100 px-1.5 py-0.5 text-[11px] font-bold text-brand-700">
            {source.ref}
          </sup>
        );
      })}
    </p>
  );
}

function SourceItem({ source }: { source: Source }) {
  return (
    <details className="rounded-lg border border-slate-200 bg-white">
      <summary className="flex cursor-pointer items-center gap-2 px-3 py-2 text-sm">
        <span className="flex h-5 min-w-5 items-center justify-center rounded bg-brand-600 px-1 text-[11px] font-bold text-white">
          {source.ref}
        </span>
        <span className="min-w-0 flex-1 truncate font-medium">
          {source.title}
          {source.heading ? <span className="font-normal text-slate-500"> — {source.heading}</span> : null}
        </span>
        <span className="shrink-0 text-xs text-slate-500">{Math.round(source.similarity * 100)}%</span>
      </summary>
      <p className="whitespace-pre-wrap border-t border-slate-100 px-3 py-2 text-xs leading-5 text-slate-600">
        {source.excerpt}
      </p>
    </details>
  );
}

function Sources({ sources }: { sources: Source[] }) {
  if (sources.length === 0) return null;
  const cited = sources.filter((source) => source.cited);
  const others = sources.filter((source) => !source.cited);
  return (
    <div className="mt-4 border-l-2 border-brand-500 pl-3">
      <p className="text-xs font-semibold text-slate-700">{cited.length > 0 ? "Sources" : "Retrieved passages"}</p>
      <div className="mt-2 space-y-1.5">
        {cited.map((source) => (
          <SourceItem key={source.ref} source={source} />
        ))}
        {others.length > 0 && (
          <details>
            <summary className="cursor-pointer text-xs font-medium text-brand-700">
              {cited.length > 0 ? `${others.length} other passage${others.length > 1 ? "s" : ""} retrieved` : "Show passages"}
            </summary>
            <div className="mt-1.5 space-y-1.5">
              {others.map((source) => (
                <SourceItem key={source.ref} source={source} />
              ))}
            </div>
          </details>
        )}
      </div>
    </div>
  );
}

export function ChatPanel(props: ChatPanelProps) {
  const { messages, pendingQuestion, loadingConversation, error, hasDocuments } = props;
  const [draft, setDraft] = useState("");
  const endRef = useRef<HTMLDivElement>(null);
  const textareaRef = useRef<HTMLTextAreaElement>(null);
  const sending = pendingQuestion !== null;

  useEffect(() => {
    endRef.current?.scrollIntoView({ behavior: "smooth", block: "end" });
  }, [messages, pendingQuestion]);

  useEffect(() => {
    const element = textareaRef.current;
    if (!element) return;
    element.style.height = "auto";
    element.style.height = `${Math.min(element.scrollHeight, 160)}px`;
  }, [draft]);

  async function submit(text: string): Promise<void> {
    const question = text.trim();
    if (!question || sending) return;
    const ok = await props.onSend(question);
    if (ok) setDraft("");
  }

  function handleKeyDown(event: KeyboardEvent<HTMLTextAreaElement>): void {
    const isDesktopKeyboard = window.matchMedia("(pointer: fine)").matches;
    if (event.key === "Enter" && !event.shiftKey && isDesktopKeyboard && !event.nativeEvent.isComposing) {
      event.preventDefault();
      void submit(draft);
    }
  }

  const isEmpty = messages.length === 0 && !sending && !loadingConversation;

  return (
    <div className="flex min-h-0 flex-1 flex-col">
      <div className="min-h-0 flex-1 overflow-y-auto px-4 py-6 md:px-8">
        <div className="mx-auto w-full max-w-3xl space-y-6">
          {loadingConversation && <p className="py-10 text-center text-sm text-slate-500">Loading conversation…</p>}

          {isEmpty && !hasDocuments && (
            <div className="mx-auto max-w-sm py-16 text-center">
              <FileIcon className="mx-auto text-brand-500" width={36} height={36} />
              <h2 className="mt-4 text-lg font-semibold">Add a document to begin</h2>
              <p className="mt-2 text-sm text-slate-500">
                Upload a .txt or .md file. KnowledgeBase AI indexes it, then answers your questions using only what the file says.
              </p>
              <button
                type="button"
                onClick={props.onOpenLibrary}
                className="mt-5 rounded-xl bg-brand-600 px-5 py-3 text-sm font-semibold text-white hover:bg-brand-700 md:hidden"
              >
                Go to documents
              </button>
            </div>
          )}

          {isEmpty && hasDocuments && (
            <div className="py-10">
              <h2 className="text-xl font-semibold tracking-tight">Ask anything about your documents</h2>
              <p className="mt-2 text-sm text-slate-500">Every answer shows the passages it came from.</p>
              <div className="mt-6 flex flex-col gap-2">
                {SUGGESTIONS.map((suggestion) => (
                  <button
                    key={suggestion}
                    type="button"
                    onClick={() => void submit(suggestion)}
                    className="rounded-xl border border-slate-200 px-4 py-3 text-left text-sm hover:border-brand-500 hover:bg-brand-50"
                  >
                    {suggestion}
                  </button>
                ))}
              </div>
            </div>
          )}

          {messages.map((message) =>
            message.role === "user" ? (
              <div key={message.id} className="flex justify-end">
                <p className="max-w-[85%] whitespace-pre-wrap rounded-2xl rounded-br-md bg-brand-600 px-4 py-2.5 text-[15px] leading-6 text-white">
                  {message.content}
                </p>
              </div>
            ) : (
              <article key={message.id} className="rounded-2xl border border-slate-200 px-4 py-4">
                <AnswerText text={message.content} sources={message.sources} />
                <Sources sources={message.sources} />
              </article>
            ),
          )}

          {pendingQuestion && (
            <>
              <div className="flex justify-end">
                <p className="max-w-[85%] whitespace-pre-wrap rounded-2xl rounded-br-md bg-brand-600 px-4 py-2.5 text-[15px] leading-6 text-white">
                  {pendingQuestion}
                </p>
              </div>
              <div role="status" aria-label="Generating answer" className="flex items-center gap-1.5 px-2 py-2">
                {[0, 150, 300].map((delay) => (
                  <span
                    key={delay}
                    className="h-2 w-2 animate-pulse rounded-full bg-brand-500"
                    style={{ animationDelay: `${delay}ms` }}
                  />
                ))}
                <span className="ml-2 text-xs text-slate-500">Searching your documents…</span>
              </div>
            </>
          )}
          <div ref={endRef} />
        </div>
      </div>

      <div className="border-t border-slate-200 bg-white px-4 pb-3 pt-3 md:px-8">
        <div className="mx-auto w-full max-w-3xl">
          {error && (
            <div role="alert" className="mb-2 flex items-start gap-2 rounded-lg border border-red-200 bg-red-50 px-3 py-2 text-sm text-red-800">
              <span className="flex-1">{error}</span>
              <button type="button" onClick={props.onDismissError} aria-label="Dismiss error" className="mt-0.5 shrink-0">
                <CloseIcon width={16} height={16} />
              </button>
            </div>
          )}
          <form
            onSubmit={(event) => {
              event.preventDefault();
              void submit(draft);
            }}
            className="flex items-end gap-2 rounded-2xl border border-slate-300 bg-white p-2 focus-within:border-brand-600"
          >
            <label htmlFor="question" className="sr-only">
              Your question
            </label>
            <textarea
              id="question"
              ref={textareaRef}
              rows={1}
              value={draft}
              maxLength={2000}
              onChange={(event) => setDraft(event.target.value)}
              onKeyDown={handleKeyDown}
              placeholder="Ask a question about your documents"
              className="max-h-40 min-h-10 flex-1 resize-none bg-transparent px-2 py-2 text-base outline-none focus-visible:ring-0 focus-visible:ring-offset-0"
            />
            <button
              type="submit"
              disabled={sending || draft.trim().length === 0}
              aria-label="Send question"
              className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-brand-600 text-white transition hover:bg-brand-700 disabled:opacity-40"
            >
              <SendIcon />
            </button>
          </form>
        </div>
      </div>
    </div>
  );
}
