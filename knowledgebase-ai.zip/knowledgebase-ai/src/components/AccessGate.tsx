"use client";

import { useState, type FormEvent } from "react";
import { api, ApiError, clearCode, storeCode } from "@/lib/client-api";
import { LogoMark } from "./icons";

interface AccessGateProps {
  status: "checking" | "locked" | "error";
  message: string | null;
  onUnlocked: () => void;
}

/** Full-screen state shown before the dashboard: loading, access-code form, or a configuration error. */
export function AccessGate({ status, message, onUnlocked }: AccessGateProps) {
  const [code, setCode] = useState("");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);

  async function submit(event: FormEvent<HTMLFormElement>): Promise<void> {
    event.preventDefault();
    setBusy(true);
    setError(null);
    try {
      await api.verifyCode(code);
      storeCode(code);
      onUnlocked();
    } catch (caught) {
      clearCode();
      setError(caught instanceof ApiError ? caught.message : "Could not verify the code.");
    } finally {
      setBusy(false);
    }
  }

  return (
    <div className="flex min-h-dvh items-center justify-center px-6 pt-safe pb-safe">
      <div className="w-full max-w-sm">
        <LogoMark className="mb-6 h-10 w-10" />
        <h1 className="text-2xl font-semibold tracking-tight">KnowledgeBase AI</h1>
        <p className="mt-1 text-sm text-slate-500">Intelligent Document Search &amp; RAG Assistant</p>

        {status === "checking" && <p className="mt-8 text-sm text-slate-500">Loading…</p>}

        {status === "error" && (
          <div role="alert" className="mt-8 rounded-xl border border-red-200 bg-red-50 p-4 text-sm text-red-800">
            {message ?? "The server could not be reached."}
          </div>
        )}

        {status === "locked" && (
          <form onSubmit={submit} className="mt-8 space-y-3">
            <label htmlFor="access-code" className="block text-sm font-medium">
              Access code
            </label>
            <input
              id="access-code"
              type="password"
              autoComplete="current-password"
              value={code}
              onChange={(event) => setCode(event.target.value)}
              className="w-full rounded-xl border border-slate-300 px-4 py-3 text-base focus:border-brand-600"
              required
            />
            {error && (
              <p role="alert" className="text-sm text-red-700">
                {error}
              </p>
            )}
            <button
              type="submit"
              disabled={busy || code.length === 0}
              className="w-full rounded-xl bg-brand-600 px-4 py-3 text-base font-semibold text-white transition hover:bg-brand-700 disabled:opacity-50"
            >
              {busy ? "Checking…" : "Unlock"}
            </button>
          </form>
        )}
      </div>
    </div>
  );
}
