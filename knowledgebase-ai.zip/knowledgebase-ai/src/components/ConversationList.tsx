"use client";

import type { Conversation } from "@/lib/schemas";
import { PlusIcon, TrashIcon } from "./icons";

interface ConversationListProps {
  conversations: Conversation[];
  activeId: string | null;
  onSelect: (id: string) => void;
  onNew: () => void;
  onDelete: (conversation: Conversation) => void;
}

export function ConversationList({ conversations, activeId, onSelect, onNew, onDelete }: ConversationListProps) {
  return (
    <section aria-labelledby="history-heading" className="px-4 py-5">
      <div className="flex items-center justify-between">
        <h2 id="history-heading" className="text-sm font-semibold">
          Conversations
        </h2>
        <button
          type="button"
          onClick={onNew}
          className="flex items-center gap-1 rounded-lg px-2 py-1 text-xs font-semibold text-brand-700 hover:bg-brand-50"
        >
          <PlusIcon width={14} height={14} />
          New chat
        </button>
      </div>

      {conversations.length === 0 ? (
        <p className="mt-3 rounded-xl border border-slate-200 px-4 py-5 text-center text-xs text-slate-500">
          Your questions and answers will be saved here.
        </p>
      ) : (
        <ul className="mt-3 space-y-1">
          {conversations.map((conversation) => (
            <li key={conversation.id} className="flex items-center gap-1">
              <button
                type="button"
                onClick={() => onSelect(conversation.id)}
                aria-current={conversation.id === activeId ? "true" : undefined}
                className={`min-w-0 flex-1 truncate rounded-lg px-3 py-2.5 text-left text-sm ${
                  conversation.id === activeId ? "bg-brand-50 font-semibold text-brand-900" : "hover:bg-slate-50"
                }`}
              >
                {conversation.title}
              </button>
              <button
                type="button"
                onClick={() => onDelete(conversation)}
                aria-label={`Delete conversation ${conversation.title}`}
                className="shrink-0 rounded-lg p-2 text-slate-400 hover:bg-red-50 hover:text-red-700"
              >
                <TrashIcon width={16} height={16} />
              </button>
            </li>
          ))}
        </ul>
      )}
    </section>
  );
}
