import type { Config } from "tailwindcss";

const config: Config = {
  content: ["./src/**/*.{ts,tsx}"],
  theme: {
    extend: {
      fontFamily: {
        sans: ["var(--font-sans)", "system-ui", "-apple-system", "Segoe UI", "sans-serif"],
      },
      colors: {
        brand: {
          50: "#eff5ff",
          100: "#dce8ff",
          200: "#bcd2ff",
          500: "#3d6fe6",
          600: "#2457d6",
          700: "#1c46b0",
          900: "#142f73",
        },
      },
    },
  },
  plugins: [],
};

export default config;
