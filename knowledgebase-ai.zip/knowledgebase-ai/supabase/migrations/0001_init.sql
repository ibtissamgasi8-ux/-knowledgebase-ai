-- KnowledgeBase AI — initial schema
-- Run this once in Supabase: SQL Editor → New query → paste → Run.
-- Requires pgvector >= 0.7 (halfvec). Supabase projects include it.

create extension if not exists vector with schema extensions;

-- ---------------------------------------------------------------
-- Documents
-- ---------------------------------------------------------------
create table if not exists public.documents (
  id            uuid primary key default gen_random_uuid(),
  title         text not null check (char_length(title) between 1 and 200),
  filename      text not null,
  file_type     text not null check (file_type in ('txt', 'md')),
  size_bytes    integer not null check (size_bytes >= 0),
  chunk_count   integer not null default 0,
  content_hash  text not null unique,
  created_at    timestamptz not null default now()
);

-- ---------------------------------------------------------------
-- Chunks (text + embedding). halfvec stores 16-bit floats: about
-- half the storage of vector(384) with negligible quality loss.
-- ---------------------------------------------------------------
create table if not exists public.chunks (
  id           uuid primary key default gen_random_uuid(),
  document_id  uuid not null references public.documents (id) on delete cascade,
  chunk_index  integer not null,
  heading      text,
  content      text not null,
  embedding    extensions.halfvec(384) not null,
  created_at   timestamptz not null default now(),
  unique (document_id, chunk_index)
);

create index if not exists chunks_embedding_hnsw_idx
  on public.chunks
  using hnsw (embedding extensions.halfvec_cosine_ops)
  with (m = 16, ef_construction = 64);

-- ---------------------------------------------------------------
-- Conversations and messages
-- ---------------------------------------------------------------
create table if not exists public.conversations (
  id          uuid primary key default gen_random_uuid(),
  title       text not null check (char_length(title) between 1 and 200),
  created_at  timestamptz not null default now(),
  updated_at  timestamptz not null default now()
);

create index if not exists conversations_updated_at_idx
  on public.conversations (updated_at desc);

create table if not exists public.messages (
  id               uuid primary key default gen_random_uuid(),
  conversation_id  uuid not null references public.conversations (id) on delete cascade,
  role             text not null check (role in ('user', 'assistant')),
  content          text not null,
  sources          jsonb not null default '[]'::jsonb,
  created_at       timestamptz not null default now()
);

create index if not exists messages_conversation_idx
  on public.messages (conversation_id, created_at);

-- ---------------------------------------------------------------
-- Semantic search function.
-- The query embedding is passed as text ("[0.1,0.2,...]") and cast
-- inside, which avoids client-side type issues with halfvec.
-- ---------------------------------------------------------------
create or replace function public.match_chunks(
  query_embedding      text,
  match_count          integer default 6,
  min_similarity       double precision default 0,
  filter_document_ids  uuid[] default null
)
returns table (
  id              uuid,
  document_id     uuid,
  document_title  text,
  chunk_index     integer,
  heading         text,
  content         text,
  similarity      double precision
)
language plpgsql
stable
set search_path = public, extensions
as $$
declare
  q extensions.halfvec(384) := query_embedding::extensions.halfvec(384);
begin
  return query
  select
    c.id,
    c.document_id,
    d.title,
    c.chunk_index,
    c.heading,
    c.content,
    (1 - (c.embedding <=> q))::double precision
  from public.chunks c
  join public.documents d on d.id = c.document_id
  where (filter_document_ids is null or c.document_id = any (filter_document_ids))
    and (1 - (c.embedding <=> q)) >= min_similarity
  order by c.embedding <=> q
  limit greatest(1, least(match_count, 20));
end;
$$;

-- ---------------------------------------------------------------
-- Security: the app talks to the database only from the server with
-- the service-role key (which bypasses RLS). Enabling RLS with no
-- policies means the public anon/authenticated roles can read nothing.
-- ---------------------------------------------------------------
alter table public.documents     enable row level security;
alter table public.chunks        enable row level security;
alter table public.conversations enable row level security;
alter table public.messages      enable row level security;

revoke execute on function public.match_chunks(text, integer, double precision, uuid[])
  from public, anon, authenticated;
grant execute on function public.match_chunks(text, integer, double precision, uuid[])
  to service_role;
