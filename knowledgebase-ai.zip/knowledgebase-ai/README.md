# KnowledgeBase AI

**Intelligent Document Search & RAG Assistant**

Upload `.txt` and `.md` files, search them by meaning, and ask questions. Answers are generated only from your documents and cite the passages they came from.

## How it works

```
Upload ──► extract text ──► chunk (≈900 chars, overlap, heading-aware)
        ──► embed (Hugging Face, 384 dims) ──► store in Supabase (pgvector halfvec + HNSW index)

Question ──► embed ──► match_chunks() cosine search ──► top-K passages
         ──► OpenRouter chat model ("answer only from context, cite [n]") ──► answer + sources
```

- **Next.js 15 (App Router) + TypeScript (strict) + Tailwind CSS 3**
- **Supabase Postgres + pgvector**: `halfvec(384)` halves vector storage; HNSW cosine index
- **Zod** validates environment variables, every request body, every database row read, and every API response on the client
- **All secrets are server-side only**. The browser never receives an API key; the Supabase service-role key is used only in API routes
- Optional **access code** (`APP_ACCESS_CODE`) protects every API route

## Folder structure

```
supabase/migrations/0001_init.sql     tables, HNSW index, match_chunks(), RLS
src/app/api/documents/                upload (POST), list (GET), delete ([id])
src/app/api/search/                   semantic search (no LLM)
src/app/api/chat/                     grounded Q&A + conversation history
src/app/api/conversations/            list, load ([id]), delete ([id])
src/app/api/health/                   live system check
src/app/api/access/                   access-code gate
src/lib/                              env, chunking, embeddings, llm, rag, schemas, supabase, http, auth
src/components/                       Dashboard, DocumentPanel, ChatPanel, SearchPanel, ...
```

## Setup

### 1. Supabase
1. Create a project at supabase.com.
2. Open **SQL Editor → New query**, paste the full contents of `supabase/migrations/0001_init.sql`, and run it.
3. In **Project Settings → API**, copy the **Project URL** and the **service_role** key.

### 2. Hugging Face
1. Create a **fine-grained token** with the permission **Make calls to Inference Providers**.
2. The default model is `intfloat/multilingual-e5-small` (384 dimensions, multilingual).
   **You must confirm that Hugging Face currently serves it** — the app's *System check* does this for you. If it fails, use another model that outputs 384 dimensions (set `HF_EMBEDDING_MODEL`), or deploy your own Inference Endpoint (set `HF_EMBEDDING_URL`). If the new model does not use E5 prefixes, set `EMBEDDING_QUERY_PREFIX` and `EMBEDDING_PASSAGE_PREFIX` to empty values.

### 3. OpenRouter
Create an API key and choose a model id from openrouter.ai/models for `OPENROUTER_MODEL`.

### 4. Environment variables
Copy `.env.example` to `.env.local` and fill it in. On Netlify, add the same variables under **Site configuration → Environment variables**. Do not wrap values in quotes there.

### 5. Run locally (computer)
```
npm install
npm run dev
```

### 6. Deploy to Netlify
1. Push this folder to a GitHub repository (`.env` files are git-ignored).
2. Netlify → **Add new site → Import an existing project** → pick the repo. The included `netlify.toml` sets the build command and Node 20; Netlify detects Next.js automatically.
3. Add the environment variables, then deploy.
4. Open the site and tap **System check** (tick *Also test the chat model*).

## Limits and design choices

| Setting | Default | Why |
|---|---|---|
| `MAX_UPLOAD_BYTES` | 150 000 | Uploads are indexed inside one serverless request |
| `MAX_CHUNKS_PER_DOCUMENT` | 200 | Keeps embedding time inside serverless time limits |
| `RAG_TOP_K` | 6 | Passages sent to the model |
| `RAG_MIN_SIMILARITY` | 0 | Raise it to drop weak matches (E5 scores are compressed: unrelated text can still score 0.7+) |

If uploads time out on your Netlify plan, lower `MAX_CHUNKS_PER_DOCUMENT`.

## Status of features

**Implemented in code** (written carefully, but see "Not yet verified"):
dashboard UI · TXT/Markdown upload · chunking · embeddings · pgvector storage · semantic search · grounded answers with source cards · conversation history · document deletion · loading/error/empty states · access code · system-check page.

**Verified**: the chunking module has a passing test suite (sentence/paragraph splitting, Markdown headings, Arabic text, CRLF/BOM, size limits). The Hugging Face router URL format was checked against Hugging Face's documentation.

**Not yet verified (needs your credentials and a real run)**:
- `npm install` / `npm run build` / type-check (dependencies could not be installed where this was written)
- That Hugging Face currently serves your chosen embedding model
- The SQL migration on your Supabase project
- OpenRouter responses, end-to-end upload → answer, and Netlify deployment

**Known limitations**: single-tenant (one shared library; no per-user accounts), `.txt`/`.md` only (no PDF), answers are not streamed, follow-up questions are retrieved using the latest question only, and there is no rate limiting beyond the optional access code.
